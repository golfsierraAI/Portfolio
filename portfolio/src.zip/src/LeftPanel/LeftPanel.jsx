import InstagramIcon from "@material-ui/icons/Instagram";
import GitHubIcon from "@material-ui/icons/GitHub";
import LinkedInIcon from "@material-ui/icons/LinkedIn";
import FacebookIcon from "@material-ui/icons/Facebook";
import "./LeftPanel.css";
var LeftPanel = () => {
  var iconClicked = (event) => {};
  return (
    <div className="leftCont">
      <div className="iconsCont">
        <a onFocus={iconClicked} className="icons" href="#">
          <InstagramIcon />
        </a>
        <a onFocus={iconClicked} className="icons" href="#">
          <GitHubIcon />
        </a>
        <a onFocus={iconClicked} className="icons" href="#">
          <LinkedInIcon />
        </a>
        <a onFocus={iconClicked} className="icons" href="#">
          <FacebookIcon />
        </a>
      </div>
      <div className="line"></div>
    </div>
  );
};
export default LeftPanel;
