import "./RightPanel.css";
var RightPanel = () => {
  return (
    <div className="rightCont">
      <p className="email">gsharma774962@gmail.com</p>
      <div className="line"></div>
    </div>
  );
};
export default RightPanel;
