import "./Header.css";
import logo from "../logo.svg";
import Button from "@material-ui/core/Button";
var Header = () => {
  return (
    <div className="Header">
      <div className="logoContainer">
        <img className="logo" src={logo} />
      </div>
      <div className="linkContainer">
        <a className="headerLinks" href="#">
          <p className="headerLinks">About</p>
        </a>
        <a className="headerLinks" href="#">
          <p className="headerLinks">Experience</p>
        </a>
        <a className="headerLinks" href="#">
          <p className="headerLinks">Work</p>
        </a>
        <a className="headerLinks" href="#">
          <p className="headerLinks">Contact</p>
        </a>
        <button className="resume">Resume</button>
      </div>
    </div>
  );
};

export default Header;
